<?php

namespace App\Controllers;

use App\Models\BarangModel;
use App\Models\KategoriModel;

class Barang extends BaseController
{
    public function index()
    {
        $model = new BarangModel();
        $data['barang'] = $model
            ->select('barang.*, kategori.nama_kategori')
            ->join('kategori', 'kategori.id_kategori = barang.id_kategori', 'left')
            ->findAll();

        return view('barang/index', $data);
    }

    public function create()
    {
        $kategoriModel = new KategoriModel();
        $data['kategori'] = $kategoriModel->findAll();
        return view('barang/create', $data);
    }

    public function store()
    {
        $model = new \App\Models\BarangModel();

        $model->insert([
            'nama_barang' => $this->request->getPost('nama_barang'),
            'id_kategori' => $this->request->getPost('id_kategori'),
            'stok'        => $this->request->getPost('stok'),
            'harga'       => $this->request->getPost('harga'),
        ]);

        return redirect()->to(base_url('barang'));
    }


    public function edit($id)
    {
        $model = new \App\Models\BarangModel();
        $kategoriModel = new \App\Models\KategoriModel();

        $data['barang']   = $model->find($id);
        $data['kategori'] = $kategoriModel->findAll();

        return view('barang/edit', $data);
    }

    public function update($id)
    {
        $model = new \App\Models\BarangModel();

        $model->update($id, [
            'nama_barang' => $this->request->getPost('nama_barang'),
            'id_kategori' => $this->request->getPost('id_kategori'),
            'stok'        => $this->request->getPost('stok'),
            'harga'       => $this->request->getPost('harga'),
        ]);

        return redirect()->to(site_url('barang'));
    }


    public function delete($id)
    {
        $model = new BarangModel();
        $model->delete($id);

        return redirect()->to('/barang');
    }
}

<?php

namespace App\Models;

use CodeIgniter\Model;

class StokMasukModel extends Model
{
    protected $table      = 'stok_masuk';
    protected $primaryKey = 'id_masuk';
    protected $returnType = 'array';
    protected $useAutoIncrement = true;

    // Kolom yang boleh diisi melalui insert/update
    protected $allowedFields = [
        'id_barang',
        'id_supplier',
        'jumlah',
        'tanggal',
        'keterangan'
    ];

    protected $useTimestamps = false;
}

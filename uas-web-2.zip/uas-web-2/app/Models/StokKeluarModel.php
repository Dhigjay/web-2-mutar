<?php

namespace App\Models;

use CodeIgniter\Model;

class StokKeluarModel extends Model
{
    protected $table      = 'stok_keluar';
    protected $primaryKey = 'id_keluar';
    protected $returnType = 'array';
    protected $useAutoIncrement = true;

    // Kolom yang boleh diisi saat insert/update
    protected $allowedFields = [
        'id_barang',
        'jumlah',
        'tanggal',
        'keterangan'
    ];

    protected $useTimestamps = false;
}

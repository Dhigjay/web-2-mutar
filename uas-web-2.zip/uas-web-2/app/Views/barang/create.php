<h2>Tambah Barang</h2>

<form action="<?= site_url('barang/store'); ?>" method="post">
    <p>
        Nama Barang<br>
        <input type="text" name="nama_barang" required>
    </p>

    <p>
        Kategori<br>
        <select name="id_kategori">
            <?php foreach ($kategori as $k): ?>
                <option value="<?= $k['id_kategori']; ?>">
                    <?= $k['nama_kategori']; ?>
                </option>
            <?php endforeach; ?>
        </select>
    </p>

    <p>
        Stok<br>
        <input type="number" name="stok" required>
    </p>

    <p>
        Harga<br>
        <input type="number" name="harga" required>
    </p>

    <button type="submit">Simpan</button>
    <a href="<?= site_url('barang'); ?>">Kembali</a>
</form>

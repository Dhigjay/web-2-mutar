<h2>Data Barang</h2>
<a href="/uas-web-2/public/barang/create">Tambah Barang</a>
<table border="1" cellpadding="6" cellspacing="0">
    <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Kategori</th>
        <th>Stok</th>
        <th>Harga</th>
    </tr>
    <?php $no = 1;
    foreach ($barang as $b): ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $b['nama_barang']; ?></td>
            <td><?= $b['nama_kategori'] ?? '-'; ?></td>
            <td><?= $b['stok']; ?></td>
            <td><?= $b['harga']; ?></td>
            

            <td>
                <a href="<?= site_url('barang/edit/' . $b['id_barang']); ?>">Edit</a>
                <a href="<?= base_url('/barang/delete/' . $b['id_barang']); ?>" onclick="return confirm('Hapus data?')">Hapus</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
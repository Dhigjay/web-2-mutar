<h2>Edit Barang</h2>

<form action="<?= site_url('barang/update/' . $barang['id_barang']); ?>" method="post">
    <p>
        Nama Barang<br>
        <input type="text" name="nama_barang" value="<?= $barang['nama_barang']; ?>" required>
    </p>

    <p>
        Kategori<br>
        <select name="id_kategori">
            <?php foreach ($kategori as $k): ?>
                <option value="<?= $k['id_kategori']; ?>"
                    <?= ($k['id_kategori'] == $barang['id_kategori']) ? 'selected' : ''; ?>>
                    <?= $k['nama_kategori']; ?>
                </option>
            <?php endforeach; ?>
        </select>
    </p>

    <p>
        Stok<br>
        <input type="number" name="stok" value="<?= $barang['stok']; ?>" required>
    </p>

    <p>
        Harga<br>
        <input type="number" name="harga" value="<?= $barang['harga']; ?>" required>
    </p>

    <button type="submit">Update</button>
    <a href="<?= site_url('barang'); ?>">Kembali</a>
</form>